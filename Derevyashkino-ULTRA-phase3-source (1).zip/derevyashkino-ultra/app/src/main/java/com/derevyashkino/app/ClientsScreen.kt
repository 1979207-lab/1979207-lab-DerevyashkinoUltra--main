package com.derevyashkino.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

private data class ClientRow(val id: String, val name: String, val phone: String, val email: String)

@Composable
fun ClientsScreen(canEdit: Boolean) {
    val db = remember { FirebaseFirestore.getInstance() }
    var clients by remember { mutableStateOf<List<ClientRow>>(emptyList()) }
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var email by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        val listener: ListenerRegistration = db.collection("clients").addSnapshotListener { snap, e ->
            if (e != null) error = e.localizedMessage ?: "Ошибка"
            clients = snap?.documents?.map { ClientRow(it.id, it.getString("name") ?: it.getString("clientName") ?: "Без имени", it.getString("phone") ?: "", it.getString("email") ?: "") } ?: emptyList()
        }
        onDispose { listener.remove() }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (canEdit) {
            Text("Новый клиент", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(name, { name = it }, label = { Text("Имя") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(phone, { phone = it }, label = { Text("Телефон") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
            Button(enabled = name.isNotBlank(), onClick = {
                db.collection("clients").add(mapOf("name" to name.trim(), "phone" to phone.trim(), "email" to email.trim()))
                    .addOnFailureListener { error = it.localizedMessage ?: "Ошибка сохранения" }
                name = ""; phone = ""; email = ""
            }) { Text("Сохранить клиента") }
        }
        Text("Клиенты", style = MaterialTheme.typography.titleLarge)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(clients, key = { it.id }) { c -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(c.name, style = MaterialTheme.typography.titleMedium); if (c.phone.isNotBlank()) Text(c.phone); if (c.email.isNotBlank()) Text(c.email) } } }
        }
    }
}
