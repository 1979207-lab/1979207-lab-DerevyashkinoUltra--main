package com.derevyashkino.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging

private val WorkshopGreen = Color(0xFF173D35)
private val WorkshopGold = Color(0xFFE7A94B)

@Composable
fun AppRoot() {
    val auth = remember { FirebaseAuth.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var profile by remember { mutableStateOf<AppUser?>(null) }
    var loading by remember { mutableStateOf(user != null) }
    var error by remember { mutableStateOf("") }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { user = it.currentUser }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(user?.uid) {
        profile = null
        if (user == null) { loading = false; return@LaunchedEffect }
        loading = true
        FirebaseFirestore.getInstance().collection("users").document(user!!.uid).get()
            .addOnSuccessListener { doc ->
                val role = doc.getString("role") ?: "Сотрудник"
                profile = AppUser(user!!.uid, user!!.email ?: "", role)
                FirebaseMessaging.getInstance().subscribeToTopic("all_users")
                loading = false
            }
            .addOnFailureListener { error = it.localizedMessage ?: "Не удалось загрузить профиль"; loading = false }
    }

    when {
        user == null -> LoginScreen(onError = { error = it }, externalError = error)
        loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = WorkshopGreen) }
        profile != null -> MainMenu(profile!!, onSignOut = { auth.signOut() })
        else -> Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("Не удалось загрузить профиль", style = MaterialTheme.typography.titleLarge)
            Text(error)
            Button(onClick = { auth.signOut() }) { Text("Выйти") }
        }
    }
}

@Composable
fun LoginScreen(onError: (String) -> Unit, externalError: String) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("login_preferences", Context.MODE_PRIVATE) }
    var email by remember { mutableStateOf(prefs.getString("email", "") ?: "") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFF3F5F1), Color(0xFFE5ECE6)))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(88.dp).background(WorkshopGreen, RoundedCornerShape(26.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("⌁", color = WorkshopGold, fontSize = 58.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(18.dp))
            Text("Деревяшкино", color = WorkshopGreen, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Ваша мастерская — под контролем", color = Color(0xFF64736C), style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(28.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(22.dp)) {
                    Text("С возвращением!", color = Color(0xFF203B33), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("Войдите, чтобы продолжить работу", color = Color(0xFF75827B), style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(22.dp))
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it; prefs.edit().putString("email", it).apply() },
                        label = { Text("Электронная почта") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Пароль") },
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = { TextButton(onClick = { showPassword = !showPassword }) { Text(if (showPassword) "Скрыть" else "Показать") } },
                        singleLine = true, shape = RoundedCornerShape(14.dp)
                    )
                    if (externalError.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(externalError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(20.dp))
                    Button(
                        enabled = !busy && email.isNotBlank() && password.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WorkshopGreen),
                        onClick = {
                            busy = true
                            FirebaseAuth.getInstance().signInWithEmailAndPassword(email.trim(), password)
                                .addOnSuccessListener { busy = false }
                                .addOnFailureListener { busy = false; onError(it.localizedMessage ?: "Ошибка входа") }
                        }
                    ) {
                        if (busy) CircularProgressIndicator(modifier = Modifier.size(21.dp), color = Color.White, strokeWidth = 2.dp)
                        else Text("Войти", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Рабочее пространство мастерской", color = Color(0xFF78877F), style = MaterialTheme.typography.labelMedium)
        }
    }
}
