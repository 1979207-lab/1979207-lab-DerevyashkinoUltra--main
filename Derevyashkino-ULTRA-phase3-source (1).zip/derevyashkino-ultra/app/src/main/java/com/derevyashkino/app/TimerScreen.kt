package com.derevyashkino.app

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun TimerScreen() {
    var running by remember { mutableStateOf(false) }
    var elapsed by remember { mutableLongStateOf(0L) }
    LaunchedEffect(running) {
        while (running) { delay(1000); elapsed += 1 }
    }
    val hours = elapsed / 3600; val minutes = (elapsed % 3600) / 60; val seconds = elapsed % 60
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Рабочий таймер", style = MaterialTheme.typography.titleLarge)
        Text("%02d:%02d:%02d".format(hours, minutes, seconds), style = MaterialTheme.typography.displayLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { running = !running }) { Text(if (running) "Пауза" else "Старт") }
            OutlinedButton(onClick = { running = false; elapsed = 0 }) { Text("Сбросить") }
        }
    }
}
