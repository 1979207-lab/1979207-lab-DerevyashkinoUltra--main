package com.derevyashkino.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.MediaController
import android.widget.VideoView
import coil.compose.AsyncImage
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.storage.FirebaseStorage
import java.util.Date

private data class ChatRow(val id: String, val text: String, val sender: String, val mediaUrl: String, val mediaType: String)

@Composable
fun ChatScreen(user: AppUser) {
    val db = remember { FirebaseFirestore.getInstance() }
    var text by remember { mutableStateOf("") }
    var rows by remember { mutableStateOf<List<ChatRow>>(emptyList()) }
    var error by remember { mutableStateOf("") }
    var uploading by remember { mutableStateOf(false) }

    fun sendMedia(uri: android.net.Uri, mediaType: String) {
        uploading = true
        val ref = FirebaseStorage.getInstance().reference.child("chat/${user.uid}/${System.currentTimeMillis()}")
        ref.putFile(uri)
            .continueWithTask { task -> if (!task.isSuccessful) throw (task.exception ?: Exception("Upload failed")); ref.downloadUrl }
            .addOnSuccessListener { download ->
                db.collection("chat").add(mapOf("text" to "", "type" to mediaType, "mediaUrl" to download.toString(), "senderUid" to user.uid, "senderEmail" to user.email, "createdAt" to Date()))
                    .addOnFailureListener { error = it.localizedMessage ?: "Не удалось отправить вложение" }
                uploading = false
            }
            .addOnFailureListener { error = it.localizedMessage ?: "Не удалось загрузить файл"; uploading = false }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) sendMedia(uri, "image") }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) sendMedia(uri, "video") }

    DisposableEffect(Unit) {
        val listener: ListenerRegistration = db.collection("chat").addSnapshotListener { snap, e ->
            if (e != null) error = e.localizedMessage ?: "Ошибка чата"
            rows = snap?.documents?.sortedBy { it.getTimestamp("createdAt")?.toDate()?.time ?: 0L }
                ?.map { ChatRow(it.id, it.getString("text") ?: "", it.getString("senderEmail") ?: "Сотрудник", it.getString("mediaUrl") ?: "", it.getString("type") ?: "text") } ?: emptyList()
        }
        onDispose { listener.remove() }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Общий чат", style = MaterialTheme.typography.titleLarge)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(rows, key = { it.id }) { m ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text(m.sender, style = MaterialTheme.typography.labelMedium)
                        if (m.text.isNotBlank()) Text(m.text)
                        if (m.mediaUrl.isNotBlank() && m.mediaType == "image") {
                            AsyncImage(
                                model = m.mediaUrl,
                                contentDescription = "Фото из чата",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxWidth().height(220.dp)
                            )
                        } else if (m.mediaUrl.isNotBlank() && m.mediaType == "video") {
                            AndroidView(
                                modifier = Modifier.fillMaxWidth().height(220.dp),
                                factory = { context ->
                                    VideoView(context).apply {
                                        setMediaController(MediaController(context).also { it.setAnchorView(this) })
                                        setVideoPath(m.mediaUrl)
                                        tag = m.mediaUrl
                                    }
                                },
                                update = { view ->
                                    if (view.tag != m.mediaUrl) {
                                        view.tag = m.mediaUrl
                                        view.setVideoPath(m.mediaUrl)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        OutlinedTextField(text, { text = it }, label = { Text("Сообщение") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = text.isNotBlank(), modifier = Modifier.weight(1f), onClick = {
                db.collection("chat").add(mapOf("text" to text.trim(), "type" to "text", "senderUid" to user.uid, "senderEmail" to user.email, "createdAt" to Date()))
                    .addOnFailureListener { error = it.localizedMessage ?: "Не удалось отправить" }
                text = ""
            }) { Text("Отправить") }
            OutlinedButton(enabled = !uploading, onClick = { imagePicker.launch("image/*") }) { Text("Фото") }
            OutlinedButton(enabled = !uploading, onClick = { videoPicker.launch("video/*") }) { Text("Видео") }
        }
        if (uploading) LinearProgressIndicator(Modifier.fillMaxWidth())
    }
}
