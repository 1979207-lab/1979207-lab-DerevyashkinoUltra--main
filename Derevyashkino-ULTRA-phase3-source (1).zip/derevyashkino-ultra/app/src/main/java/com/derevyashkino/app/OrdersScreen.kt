package com.derevyashkino.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import java.util.Date

private data class OrderRow(val id: String, val client: String, val service: String, val amount: Double, val status: String, val payment: String)

@Composable
fun OrdersScreen(canEdit: Boolean) {
    val db = remember { FirebaseFirestore.getInstance() }
    var rows by remember { mutableStateOf<List<OrderRow>>(emptyList()) }
    var client by remember { mutableStateOf("") }
    var service by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf("Все") }
    var message by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        val registration: ListenerRegistration = db.collection("orders").addSnapshotListener { snapshot, error ->
            if (error != null) message = error.localizedMessage ?: "Ошибка загрузки"
            rows = snapshot?.documents?.map { d -> OrderRow(d.id, d.getString("clientName") ?: d.getString("client") ?: "Без клиента", d.getString("service") ?: "", (d.get("amount") as? Number)?.toDouble() ?: 0.0, d.getString("status") ?: "новый", d.getString("payment") ?: "не оплачено") } ?: emptyList()
        }
        onDispose { registration.remove() }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (canEdit) {
            Text("Новый заказ", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(client, { client = it }, label = { Text("Клиент") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(service, { service = it }, label = { Text("Услуга / изделие") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(amount, { amount = it }, label = { Text("Сумма") }, modifier = Modifier.fillMaxWidth())
            Button(enabled = client.isNotBlank() && service.isNotBlank() && amount.toDoubleOrNull() != null, onClick = {
                val data = mapOf("clientName" to client.trim(), "service" to service.trim(), "amount" to amount.toDouble(), "status" to "новый", "payment" to "не оплачено", "createdAt" to Date())
                db.collection("orders").add(data).addOnFailureListener { message = it.localizedMessage ?: "Не удалось сохранить" }
                client = ""; service = ""; amount = ""
            }) { Text("Добавить заказ") }
            Spacer(Modifier.height(12.dp))
        }
        Text("Заказы", style = MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Все", "новый", "в работе", "выполнен", "отменён").forEach { f ->
                FilterChip(selected = statusFilter == f, onClick = { statusFilter = f }, label = { Text(f) })
            }
        }
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rows.filter { statusFilter == "Все" || it.status.equals(statusFilter, true) }, key = { it.id }) { order ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(order.client, style = MaterialTheme.typography.titleMedium)
                        Text(order.service)
                        Text("${order.amount} ₽ · ${order.status} · ${order.payment}")
                        if (canEdit) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("в работе", "выполнен", "отменён").forEach { state ->
                                TextButton(onClick = { db.collection("orders").document(order.id).update("status", state) }) { Text(state) }
                            }
                        }
                    }
                }
            }
        }
    }
}
