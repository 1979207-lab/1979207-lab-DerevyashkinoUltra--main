package com.derevyashkino.app

data class AppUser(val uid: String, val email: String, val role: String)
