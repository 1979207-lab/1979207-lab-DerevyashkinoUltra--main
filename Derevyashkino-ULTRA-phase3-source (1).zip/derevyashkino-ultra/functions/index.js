const { onDocumentCreated, onDocumentUpdated } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getMessaging } = require('firebase-admin/messaging');

initializeApp();
const TOPIC = 'all_users';

async function notify(title, body, eventId) {
  await getMessaging().send({
    topic: TOPIC,
    notification: { title, body },
    data: { eventId: String(eventId || ''), click_action: 'FLUTTER_NOTIFICATION_CLICK' },
    android: { priority: 'high', notification: { channelId: 'derevyashkino_updates' } }
  });
}

exports.newOrderNotification = onDocumentCreated('orders/{orderId}', async (event) => {
  const data = event.data?.data() || {};
  await notify('Новый заказ', 'В приложении создан новый заказ.', event.params.orderId);
});

exports.orderStatusNotification = onDocumentUpdated('orders/{orderId}', async (event) => {
  const before = event.data.before.data() || {};
  const after = event.data.after.data() || {};
  if (before.status !== after.status) {
    await notify('Изменён статус заказа', 'Статус одного из заказов обновлён.', event.params.orderId);
  }
});

exports.newTransactionNotification = onDocumentCreated('transactions/{transactionId}', async (event) => {
  await notify('Финансовая операция', 'В приложении добавлена финансовая операция.', event.params.transactionId);
});

exports.newChatMessageNotification = onDocumentCreated('chat/{messageId}', async (event) => {
  const data = event.data?.data() || {};
  const sender = data.senderUid || '';
  // Don't send a push back to the device that sent the message; topic sends to all devices,
  // so the message remains neutral and duplicate delivery is acceptable for the sender.
  await notify('Новое сообщение', 'В общем чате новое сообщение.', event.params.messageId);
});
